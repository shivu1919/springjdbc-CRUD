package com.crud.SpringCRUD.DAO;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository
public class UpdateData {
	
	@Autowired
	private JdbcTemplate template;
	
	public void update() {
		//updating the sales value for xyz from 1200 to 12000
		String sql = "update salesman set sales=12000 where id=2";
		template.update(sql);
		System.out.println("Data is updated successfully");
	}

}
