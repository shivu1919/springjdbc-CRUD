package com.crud.SpringCRUD.DAO;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository
public class DeleteData {
	
	@Autowired
	private JdbcTemplate template;
	
	public void delete() {
		String sql = "delete from salesman where id=2";
		template.update(sql);
		System.out.println("Data is deleted successfully");
	}
}
