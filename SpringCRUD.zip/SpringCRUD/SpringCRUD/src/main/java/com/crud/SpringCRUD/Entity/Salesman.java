package com.crud.SpringCRUD.Entity;

import org.springframework.stereotype.Component;

@Component
public class Salesman {
	
	private int id;
	private String name;
	private String dept;
	private int sales;
	private int target;
	public Salesman() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Salesman(int id, String name, String dept, int sales, int target) {
		super();
		this.id = id;
		this.name = name;
		this.dept = dept;
		this.sales = sales;
		this.target = target;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDept() {
		return dept;
	}
	public void setDept(String dept) {
		this.dept = dept;
	}
	public int getSales() {
		return sales;
	}
	public void setSales(int sales) {
		this.sales = sales;
	}
	public int getTarget() {
		return target;
	}
	public void setTarget(int target) {
		this.target = target;
	}
	@Override
	public String toString() {
		return "Salesman [id=" + id + ", name=" + name + ", dept=" + dept + ", sales=" + sales + ", target=" + target
				+ "]";
	}
	
	
	

}
