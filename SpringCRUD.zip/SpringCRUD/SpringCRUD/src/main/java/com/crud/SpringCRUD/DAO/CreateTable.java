package com.crud.SpringCRUD.DAO;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository
public class CreateTable {
	
	@Autowired
	private JdbcTemplate template;
	
	public void write() {
		String query = "create table salesman(id int, name varchar(30), dept varchar(20), sales int, target int)";
		template.update(query);
	}
}
