package com.crud.SpringCRUD;

import java.util.List;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;

import com.crud.SpringCRUD.DAO.ReadData;
import com.crud.SpringCRUD.Entity.Salesman;

@SpringBootApplication
public class SpringCrudApplication {

	public static void main(String[] args) {
		ConfigurableApplicationContext con = SpringApplication.run(SpringCrudApplication.class, args);
	
		//creating the first object of Salesman
		
		Salesman s1 = con.getBean(Salesman.class);
		
		//setting the values to first salesman
		
		s1.setId(1);
		s1.setName("ABC");
		s1.setDept("Softwares");
		s1.setSales(12000);
		s1.setTarget(9000);
	
		
		//creating the object of DAO
		
//		CreateTable cd = con.getBean(CreateTable.class);
//		cd.write();
		
		//creating the object of write class
//		WriteData wd = con.getBean(WriteData.class);
		
		//wd.write(s1);
		
		//create the object of second salesman
		
		Salesman s2 = con.getBean(Salesman.class);
		s2.setId(2);
		s2.setName("xyz");
		s2.setDept("course");
		s2.setSales(1200);
		s2.setTarget(10000);
		
//		WriteData wd = con.getBean(WriteData.class);
//		
//		wd.write(s2);
		
		//creating the object of UpdateData class
		
//		UpdateData ud = con.getBean(UpdateData.class);
//		ud.update();
		
		
		
		//Creating the object of delete class
//		DeleteData dd = con.getBean(DeleteData.class);
//		dd.delete();
		
		//creating the object of ReadData class
		ReadData rd = con.getBean(ReadData.class);
		
		List<Salesman> sm = rd.read();
		
		for(Salesman s:sm) {
			System.out.println("Sales= "+s.getSales()+" Target = "+s.getTarget());
		}
		
		
		
		
		
	
	}

}
