package com.crud.SpringCRUD.DAO;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.crud.SpringCRUD.Entity.Salesman;

@Repository
public class ReadData {
	
	@Autowired
	private JdbcTemplate template;
	
	public List<Salesman> read() {
		String sql = "select *from salesman";
		
		RowMapper <Salesman> rowmapper=(rs,rowNum)->{
			Salesman s = new Salesman();
			
			s.setId(rs.getInt("id"));
			s.setName(rs.getString("name"));
			s.setDept(rs.getString("dept"));
			s.setSales(rs.getInt("sales"));
			s.setTarget(rs.getInt("target"));
			
			return s;
		};
		
		return template.query(sql, rowmapper);
	}
}
