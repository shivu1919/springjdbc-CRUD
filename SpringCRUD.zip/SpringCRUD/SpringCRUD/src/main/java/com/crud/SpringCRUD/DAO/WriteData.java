package com.crud.SpringCRUD.DAO;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.crud.SpringCRUD.Entity.Salesman;


@Repository
public class WriteData {
	
	@Autowired
	private JdbcTemplate template;
	
	public void write(Salesman s) {
		String sql = "insert into salesman values(?,?,?,?,?)";
		template.update(sql, s.getId(),s.getName(),s.getDept(),s.getSales(),s.getTarget() );
		System.out.println("Writing the data is successful");
	}
}
